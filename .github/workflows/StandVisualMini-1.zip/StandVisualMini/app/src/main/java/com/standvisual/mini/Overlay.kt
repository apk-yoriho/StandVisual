package com.standvisual.mini

import android.animation.ValueAnimator
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Objects
import java.util.Random
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin

/* ───────────────────────── Частицы ───────────────────────── */

class ParticleView(c: Context, private val cfg: Cfg) : View(c) {
    private class Pt {
        var x = 0f; var y = 0f; var vx = 0f; var vy = 0f
        var r = 0f; var ph = 0f; var rot = 0f; var vr = 0f
    }

    private val list = ArrayList<Pt>()
    private val rnd = Random()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val d = resources.displayMetrics.density
    private var last = 0L
    private var t = 0f
    private var type = -1

    private fun reset(p: Pt, init: Boolean) {
        val w = width.toFloat(); val h = height.toFloat()
        p.x = rnd.nextFloat() * w
        p.ph = rnd.nextFloat() * 6.28f
        p.rot = rnd.nextFloat() * 360f
        p.vr = (rnd.nextFloat() - .5f) * 120f
        p.vx = (rnd.nextFloat() - .5f) * 20f
        p.r = when (type) {
            1 -> 0.8f + rnd.nextFloat() * 0.6f
            4, 5, 6 -> 4f + rnd.nextFloat() * 5f
            else -> 1.5f + rnd.nextFloat() * 2.5f
        }
        p.vy = when (type) {
            0 -> 50 + rnd.nextFloat() * 70
            1 -> 700 + rnd.nextFloat() * 400
            2 -> 6 + rnd.nextFloat() * 10
            3 -> -(80 + rnd.nextFloat() * 120)
            4 -> 40 + rnd.nextFloat() * 50
            5 -> -(30 + rnd.nextFloat() * 50)
            else -> -(25 + rnd.nextFloat() * 45)
        }
        val rising = type == 3 || type == 5 || type == 6
        p.y = if (init) rnd.nextFloat() * h else if (rising) h + 10 * d else -10 * d
    }

    override fun onDraw(cv: Canvas) {
        if (!cfg.pOn || width == 0) { last = 0; return }
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1e9f).coerceAtMost(0.05f)
        last = now; t += dt

        if (type != cfg.pType) { type = cfg.pType; list.clear() }
        val n = cfg.pCount.toInt()
        while (list.size < n) list.add(Pt().also { reset(it, true) })
        while (list.size > n) list.removeAt(list.size - 1)

        val sp = cfg.pSpeed; val sz = cfg.pSize; val a = cfg.pAlpha
        val glow = cfg.pGlow; val sway = cfg.pSway
        val w = width.toFloat(); val h = height.toFloat()

        for (p in list) {
            val swayV = if (type == 1) 0f else sin(t * 1.4f + p.ph) * sway * 35f
            p.x += (p.vx + swayV) * dt * sp * d
            p.y += p.vy * dt * sp * d
            p.rot += p.vr * dt
            if (type == 1) p.x -= 60f * sway * dt * d
            if (p.y > h + 20 * d || p.y < -20 * d || p.x < -20 * d || p.x > w + 20 * d) reset(p, false)

            var al = a
            if (type == 2) al *= 0.4f + 0.6f * (0.5f + 0.5f * sin(t * 2f + p.ph))
            if (type == 3) al *= (p.y / h).coerceIn(0f, 1f)

            val r = p.r * d * sz
            paint.color = cfg.pColor
            if (glow > 0f && type != 1) {
                paint.style = Paint.Style.FILL
                paint.alpha = (255 * al * 0.18f * glow).toInt().coerceIn(0, 255)
                cv.drawCircle(p.x, p.y, r * (2f + glow * 3f), paint)
            }
            paint.alpha = (255 * al).toInt().coerceIn(0, 255)

            when (type) {
                0, 3 -> {
                    paint.style = Paint.Style.FILL
                    cv.drawCircle(p.x, p.y, r, paint)
                }
                1 -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = r * 1.1f
                    cv.drawLine(p.x, p.y, p.x + r * 14f * sway * 0.3f, p.y - r * 14f, paint)
                }
                2 -> {
                    paint.style = Paint.Style.FILL
                    path.reset()
                    for (i in 0 until 8) {
                        val ang = i * PI / 4 - PI / 2
                        val rr = if (i % 2 == 0) r * 2f else r * 0.6f
                        val px = p.x + cos(ang).toFloat() * rr
                        val py = p.y + sin(ang).toFloat() * rr
                        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                    }
                    path.close()
                    cv.drawPath(path, paint)
                }
                4 -> {
                    paint.style = Paint.Style.FILL
                    cv.save(); cv.translate(p.x, p.y); cv.rotate(p.rot)
                    cv.drawOval(-r * 1.3f, -r * .7f, r * 1.3f, r * .7f, paint)
                    cv.restore()
                }
                5 -> {
                    paint.style = Paint.Style.FILL
                    path.reset()
                    path.moveTo(0f, r * .9f)
                    path.cubicTo(-r * 2f, -r * .2f, -r * .8f, -r * 1.6f, 0f, -r * .6f)
                    path.cubicTo(r * .8f, -r * 1.6f, r * 2f, -r * .2f, 0f, r * .9f)
                    path.close()
                    cv.save(); cv.translate(p.x, p.y); cv.rotate(sin(t + p.ph) * 15f)
                    cv.drawPath(path, paint)
                    cv.restore()
                }
                else -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = d * 1.2f
                    cv.drawCircle(p.x, p.y, r, paint)
                    paint.style = Paint.Style.FILL
                    cv.drawCircle(p.x - r * .35f, p.y - r * .35f, r * .18f, paint)
                }
            }
        }
    }
}

/* ───────────── Цветокоррекция / ночной режим / виньетка ───────────── */

class TintView(c: Context, private val cfg: Cfg) : View(c) {
    private val paint = Paint()
    private val vg = Paint()
    private var sig = 0

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        vg.shader = RadialGradient(
            w / 2f, h / 2f, hypot(w.toFloat(), h.toFloat()) / 2f,
            intArrayOf(0, 0, Color.BLACK), floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP
        )
    }

    fun refresh() {
        val s = Objects.hash(cfg.tOn, cfg.tColor, cfg.tAmt, cfg.night, cfg.nightLvl, cfg.dim, cfg.vig)
        if (s != sig) { sig = s; invalidate() }
    }

    override fun onDraw(cv: Canvas) {
        if (cfg.tOn) {
            paint.color = cfg.tColor; paint.alpha = (255 * cfg.tAmt).toInt(); cv.drawPaint(paint)
        }
        if (cfg.night) {
            paint.color = 0xFF050A1E.toInt(); paint.alpha = (255 * cfg.nightLvl * 0.85f).toInt(); cv.drawPaint(paint)
        }
        if (cfg.dim > 0f) {
            paint.color = Color.BLACK; paint.alpha = (255 * cfg.dim * 0.8f).toInt(); cv.drawPaint(paint)
        }
        if (cfg.vig > 0f) {
            vg.alpha = (255 * cfg.vig).toInt().coerceIn(0, 255); cv.drawPaint(vg)
        }
    }
}

/* ───────────── Владелец жизненного цикла для Compose в сервисе ───────────── */

class SvOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val reg = LifecycleRegistry(this)
    private val ssc = SavedStateRegistryController.create(this)
    override val lifecycle: Lifecycle get() = reg
    override val savedStateRegistry: SavedStateRegistry get() = ssc.savedStateRegistry
    override val viewModelStore = ViewModelStore()

    fun start() {
        ssc.performAttach(); ssc.performRestore(null)
        reg.currentState = Lifecycle.State.RESUMED
    }

    fun stop() {
        reg.currentState = Lifecycle.State.DESTROYED
        viewModelStore.clear()
    }
}

/* ───────────────────────── Сервис оверлея ───────────────────────── */

class OverlayService : Service() {

    companion object {
        var running by mutableStateOf(false)
        fun start(c: Context) {
            ContextCompat.startForegroundService(c, Intent(c, OverlayService::class.java))
        }
        fun stop(c: Context) { c.stopService(Intent(c, OverlayService::class.java)) }
    }

    private lateinit var wm: WindowManager
    private lateinit var cfg: Cfg
    private val h = Handler(Looper.getMainLooper())
    private val owner = SvOwner()
    private val d: Float get() = resources.displayMetrics.density

    private var tint: TintView? = null
    private var particles: ParticleView? = null
    private var mini: LinearLayout? = null
    private var title: TextView? = null
    private var info: TextView? = null
    private var bar: FrameLayout? = null
    private var pill: View? = null
    private var menuView: ComposeView? = null
    private var menuShown by mutableStateOf(false)
    private var pulse: ValueAnimator? = null

    @Volatile private var alive = false
    @Volatile private var ping = -1
    private var fps = 0
    private var fpsCount = 0
    private var lastFpsT = 0L
    private var tickN = 0
    private var lastAcc = 0

    private val NT = LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE or
            LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        cfg = (application as App).cfg
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        owner.start()
        startFg()
        try {
            addTint(); addParticles(); addMini(); addBar()
        } catch (e: Exception) {
            stopSelf(); return
        }
        alive = true
        Choreographer.getInstance().postFrameCallback(frame)
        startPing()
        running = true
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_NOT_STICKY

    override fun onDestroy() {
        alive = false
        running = false
        Choreographer.getInstance().removeFrameCallback(frame)
        h.removeCallbacksAndMessages(null)
        pulse?.cancel()
        listOf<View?>(tint, particles, mini, bar, menuView).forEach { v ->
            if (v != null) runCatching { wm.removeView(v) }
        }
        owner.stop()
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("sv", "Stand Visual Mini", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, "sv")
            .setContentTitle("Stand Visual Mini")
            .setContentText("Оверлей работает")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 1, n,
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        )
    }

    private fun full(flags: Int) = LP(
        LP.MATCH_PARENT, LP.MATCH_PARENT, LP.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
    ).apply {
        if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = LP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }

    private fun addTint() {
        tint = TintView(this, cfg).also { wm.addView(it, full(NT)) }
    }

    private fun addParticles() {
        particles = ParticleView(this, cfg).also { wm.addView(it, full(NT)) }
    }

    /** Кнопка «Stand visual mini : fps, ping» — перетаскивается, тап открывает/закрывает меню. */
    private fun addMini() {
        val bg = GradientDrawable().apply {
            setColor(0xD90E0E18.toInt()); cornerRadius = 12 * d
            setStroke((1.5f * d).toInt(), cfg.accent)
        }
        lastAcc = cfg.accent
        title = TextView(this).apply {
            text = "Stand visual mini"; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD; textSize = 11f
        }
        info = TextView(this).apply { setTextColor(0xFFB8C0FF.toInt()); textSize = 10f }
        val ll = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            val ph = (10 * d).toInt(); val pv = (6 * d).toInt()
            setPadding(ph, pv, ph, pv)
            addView(title); addView(info)
        }
        val p = LP(
            LP.WRAP_CONTENT, LP.WRAP_CONTENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS or LP.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (12 * d).toInt(); y = (10 * d).toInt() }

        ll.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false
                        v.animate().scaleX(.94f).scaleY(.94f).setDuration(80).start()
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx; val dy = e.rawY - sy
                        if (abs(dx) > 8 * d || abs(dy) > 8 * d) moved = true
                        if (moved) {
                            p.x = ox + dx.toInt(); p.y = oy + dy.toInt()
                            wm.updateViewLayout(v, p)
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                        if (e.action == MotionEvent.ACTION_UP && !moved) toggleMenu()
                    }
                }
                return true
            }
        })
        wm.addView(ll, p)
        mini = ll
        ll.scaleX = .6f; ll.scaleY = .6f
        ll.animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(OvershootInterpolator()).start()
    }

    /** Тонкая полоска снизу: тап открывает/закрывает меню. */
    private fun addBar() {
        val pl = View(this).apply {
            background = GradientDrawable().apply { setColor(cfg.accent); cornerRadius = 10 * d }
        }
        pill = pl
        val fl = FrameLayout(this).apply {
            addView(pl, FrameLayout.LayoutParams((110 * d).toInt(), (4 * d).toInt(), Gravity.CENTER))
            setOnClickListener { toggleMenu() }
        }
        val p = LP(
            (150 * d).toInt(), (26 * d).toInt(), LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS or LP.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = (2 * d).toInt() }
        wm.addView(fl, p)
        bar = fl
        pulse = ValueAnimator.ofFloat(.8f, 1f).apply {
            duration = 1400; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
            addUpdateListener { pl.scaleX = it.animatedValue as Float }
            start()
        }
    }

    /* меню */

    private fun toggleMenu() {
        if (menuView == null) openMenu() else if (menuShown) closeMenu()
    }

    private fun openMenu() {
        val dm = resources.displayMetrics
        val land = dm.widthPixels > dm.heightPixels
        val w = (dm.widthPixels * if (land) 0.56f else 0.94f).toInt()
        val hh = (dm.heightPixels * if (land) 0.90f else 0.80f).toInt()
        val cv = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setContent { OverlayMenu(cfg, menuShown) { closeMenu() } }
        }
        menuShown = true
        wm.addView(
            cv,
            LP(
                w, hh, LP.TYPE_APPLICATION_OVERLAY,
                LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCH_MODAL or LP.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.CENTER }
        )
        menuView = cv
    }

    private fun closeMenu() {
        val v = menuView ?: return
        menuShown = false
        h.postDelayed({
            runCatching { wm.removeView(v) }
            if (menuView === v) menuView = null
        }, 300)
    }

    /* FPS (частота кадров экрана) и применение настроек */

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            if (!alive) return
            fpsCount++
            if (lastFpsT == 0L) lastFpsT = t
            if (t - lastFpsT >= 500_000_000L) {
                fps = (fpsCount * 1e9 / (t - lastFpsT)).roundToInt()
                fpsCount = 0; lastFpsT = t
                updateText()
            }
            if (cfg.pOn) particles?.invalidate()
            tickN++
            if (tickN % 6 == 0) { tint?.refresh(); applyUi() }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun updateText() {
        val parts = ArrayList<String>()
        if (cfg.mFps) parts.add("FPS $fps")
        if (cfg.mPing) parts.add("Ping " + (if (ping < 0) "--" else "$ping ms"))
        info?.apply {
            text = parts.joinToString(" | ")
            visibility = if (parts.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    private fun applyUi() {
        mini?.let {
            it.visibility = if (cfg.mOn) View.VISIBLE else View.GONE
            it.alpha = cfg.mAlpha
        }
        title?.textSize = 11f * cfg.mSize
        info?.textSize = 10f * cfg.mSize
        bar?.let {
            it.visibility = if (cfg.bOn) View.VISIBLE else View.GONE
            it.alpha = cfg.bAlpha
        }
        if (cfg.accent != lastAcc) {
            lastAcc = cfg.accent
            (mini?.background as? GradientDrawable)?.setStroke((1.5f * d).toInt(), lastAcc)
            (pill?.background as? GradientDrawable)?.setColor(lastAcc)
        }
    }

    /** Пинг до 1.1.1.1 (общий пинг сети, не до сервера игры). */
    private fun startPing() {
        thread(isDaemon = true) {
            while (alive) {
                val t0 = System.nanoTime()
                ping = try {
                    Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }
                    ((System.nanoTime() - t0) / 1_000_000).toInt()
                } catch (e: Exception) { -1 }
                try { Thread.sleep(2000) } catch (e: InterruptedException) { return@thread }
            }
        }
    }
}
