package com.standvisual.mini

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.reflect.KProperty

class App : Application() {
    lateinit var cfg: Cfg
    override fun onCreate() {
        super.onCreate()
        cfg = Cfg(this)
    }
}

/** Все настройки. Каждое поле — Compose-state + автосохранение в SharedPreferences. */
class Cfg(ctx: Context) {
    private val sp = ctx.getSharedPreferences("sv", Context.MODE_PRIVATE)

    inner class P<T : Any>(private val key: String, private val def: T) {
        private val st = mutableStateOf(load())

        @Suppress("UNCHECKED_CAST")
        private fun load(): T = when (def) {
            is Boolean -> sp.getBoolean(key, def) as T
            is Int -> sp.getInt(key, def) as T
            is Float -> sp.getFloat(key, def) as T
            else -> sp.getString(key, def as String) as T
        }

        operator fun getValue(r: Any?, p: KProperty<*>): T = st.value
        operator fun setValue(r: Any?, p: KProperty<*>, v: T) {
            st.value = v
            val e = sp.edit()
            when (v) {
                is Boolean -> e.putBoolean(key, v)
                is Int -> e.putInt(key, v)
                is Float -> e.putFloat(key, v)
                else -> e.putString(key, v as String)
            }
            e.apply()
        }
    }

    // доступ
    var unlocked by P("unlocked", false)

    // частицы
    var pOn by P("pOn", true)
    var pType by P("pType", 0)            // 0 снег,1 дождь,2 звёзды,3 искры,4 листья,5 сердца,6 пузыри
    var pCount by P("pCount", 80f)
    var pSpeed by P("pSpeed", 1f)
    var pSize by P("pSize", 1f)
    var pAlpha by P("pAlpha", 0.85f)
    var pGlow by P("pGlow", 0.5f)
    var pSway by P("pSway", 0.5f)
    var pColor by P("pColor", 0xFFFFFFFF.toInt())

    // цвет / ночь
    var tOn by P("tOn", false)
    var tColor by P("tColor", 0xFFFF9A3D.toInt())
    var tAmt by P("tAmt", 0.2f)
    var night by P("night", false)
    var nightLvl by P("nightLvl", 0.5f)
    var dim by P("dim", 0f)
    var vig by P("vig", 0f)

    // мини-кнопка и полоска
    var mOn by P("mOn", true)
    var mFps by P("mFps", true)
    var mPing by P("mPing", true)
    var mSize by P("mSize", 1f)
    var mAlpha by P("mAlpha", 0.95f)
    var bOn by P("bOn", true)
    var bAlpha by P("bAlpha", 0.6f)

    // вид меню
    var accent by P("accent", 0xFF7C5CFF.toInt())
    var uiScale by P("uiScale", 1f)
    var uiAlpha by P("uiAlpha", 0.96f)
    var font by P("font", 0)
}
