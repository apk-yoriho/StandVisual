package com.standvisual.mini

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

const val CHANNEL_LINK = "https://t.me/standvisualsover"

val LocalAccent = compositionLocalOf { Color(0xFF7C5CFF) }

val palette = listOf(
    0xFFFFFFFF, 0xFF7C5CFF, 0xFF00E5FF, 0xFFFF4D8D,
    0xFF4DFF88, 0xFFFFD54D, 0xFFFF7A3D, 0xFF9AD0FF
).map { it.toInt() }

private val fontNames = listOf("Обычный", "Sans", "Serif", "Mono", "Рукописный")
private val fonts = listOf(
    FontFamily.Default, FontFamily.SansSerif, FontFamily.Serif, FontFamily.Monospace, FontFamily.Cursive
)

private val presetNames = listOf("Тёплый", "Холодный", "Розовый", "Зелёный", "Закат")
private val presetColors = listOf(0xFFFF9A3D, 0xFF3D8BFF, 0xFFFF4DA6, 0xFF3DFF8B, 0xFFFF5E3A).map { it.toInt() }

fun openUrl(ctx: Context, url: String) {
    runCatching {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

/* ─────────────── Меню поверх игры (с анимацией появления) ─────────────── */

@Composable
fun OverlayMenu(cfg: Cfg, visible: Boolean, onClose: () -> Unit) {
    val st = remember { MutableTransitionState(false) }
    LaunchedEffect(visible) { st.targetState = visible }
    AnimatedVisibility(
        visibleState = st,
        enter = fadeIn(tween(240)) + scaleIn(tween(280), initialScale = .9f),
        exit = fadeOut(tween(200)) + scaleOut(tween(220), targetScale = .9f)
    ) {
        MenuPanel(cfg, onClose, true, Modifier.fillMaxSize())
    }
}

/* ─────────────── Основная панель ─────────────── */

@Composable
fun MenuPanel(cfg: Cfg, onClose: (() -> Unit)?, scroll: Boolean, modifier: Modifier = Modifier) {
    val acc = Color(cfg.accent)
    val base = LocalDensity.current
    val fam = fonts[cfg.font.coerceIn(0, fonts.lastIndex)]
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("✨ Частицы", "🎨 Цвет", "🔘 Кнопка", "⚙ Меню")

    CompositionLocalProvider(
        LocalAccent provides acc,
        LocalContentColor provides Color.White,
        LocalDensity provides Density(base.density * cfg.uiScale, base.fontScale)
    ) {
        ProvideTextStyle(TextStyle(fontFamily = fam)) {
            val shape = RoundedCornerShape(22.dp)
            Column(
                modifier
                    .clip(shape)
                    .background(
                        Brush.verticalGradient(listOf(Color(0xFF16162A), Color(0xFF0B0B14))),
                        shape, cfg.uiAlpha
                    )
                    .border(1.dp, acc.copy(alpha = .45f), shape)
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Stand Visual Mini", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = acc)
                        Text("overlay • beta", fontSize = 11.sp, color = Color(0x99FFFFFF))
                    }
                    if (onClose != null) {
                        Box(
                            Modifier.size(34.dp).clip(CircleShape).background(Color(0x22FFFFFF))
                                .clickable(onClick = onClose),
                            contentAlignment = Alignment.Center
                        ) { Text("✕", fontSize = 14.sp) }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    tabs.forEachIndexed { i, s -> Chip(s, tab == i) { tab = i } }
                }
                Spacer(Modifier.height(8.dp))

                val bodyMod = if (scroll) Modifier.weight(1f).verticalScroll(rememberScrollState()) else Modifier
                Column(bodyMod) {
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = { fadeIn(tween(240)) togetherWith fadeOut(tween(140)) },
                        label = "tab"
                    ) { t ->
                        Column {
                            when (t) {
                                0 -> ParticlesTab(cfg)
                                1 -> ColorTab(cfg)
                                2 -> ButtonTab(cfg)
                                else -> MenuTab(cfg)
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Credits()
                }
            }
        }
    }
}

/* ─────────────── Вкладки ─────────────── */

private val pct: (Float) -> String = { "${(it * 100).roundToInt()}%" }

@Composable
fun ParticlesTab(c: Cfg) = Column {
    SwitchRow("Включить частицы", c.pOn) { c.pOn = it }
    Label("Тип частиц")
    Chips(
        listOf("❄ Снег", "🌧 Дождь", "⭐ Звёзды", "✨ Искры", "🍂 Листья", "❤ Сердца", "🫧 Пузыри"),
        c.pType
    ) { c.pType = it }
    SliderRow("Количество", c.pCount, 10f..300f, { it.toInt().toString() }) { c.pCount = it }
    SliderRow("Скорость", c.pSpeed, 0.2f..3f, { "x%.1f".format(it) }) { c.pSpeed = it }
    SliderRow("Размер", c.pSize, 0.5f..3f, { "x%.1f".format(it) }) { c.pSize = it }
    SliderRow("Прозрачность", c.pAlpha, 0.1f..1f, pct) { c.pAlpha = it }
    SliderRow("Свечение (glow)", c.pGlow, 0f..1f, pct) { c.pGlow = it }
    SliderRow("Покачивание / ветер", c.pSway, 0f..1f, pct) { c.pSway = it }
    Label("Цвет частиц")
    ColorRow(c.pColor) { c.pColor = it }
}

@Composable
fun ColorTab(c: Cfg) = Column {
    SwitchRow("Цветовой фильтр", c.tOn) { c.tOn = it }
    Label("Пресеты")
    Chips(presetNames, presetColors.indexOf(c.tColor)) { c.tColor = presetColors[it]; c.tOn = true }
    SliderRow("Интенсивность", c.tAmt, 0f..0.6f, pct) { c.tAmt = it }
    Label("Свой цвет")
    ColorRow(c.tColor) { c.tColor = it; c.tOn = true }
    Spacer(Modifier.height(8.dp))
    SwitchRow("🌙 Night mode (beta)", c.night) { c.night = it }
    SliderRow("Темнота ночи", c.nightLvl, 0f..1f, pct) { c.nightLvl = it }
    SliderRow("Затемнение экрана", c.dim, 0f..1f, pct) { c.dim = it }
    SliderRow("Виньетка по краям", c.vig, 0f..1f, pct) { c.vig = it }
    Text(
        "Оверлей накладывает цветной слой поверх экрана. Контраст и насыщенность так изменить нельзя.",
        fontSize = 11.sp, color = Color(0x77FFFFFF), modifier = Modifier.padding(top = 4.dp)
    )
}

@Composable
fun ButtonTab(c: Cfg) = Column {
    SwitchRow("Мини-кнопка (слева вверху)", c.mOn) { c.mOn = it }
    SwitchRow("Показывать FPS", c.mFps) { c.mFps = it }
    SwitchRow("Показывать Ping", c.mPing) { c.mPing = it }
    SliderRow("Размер кнопки", c.mSize, 0.7f..2f, { "x%.1f".format(it) }) { c.mSize = it }
    SliderRow("Прозрачность кнопки", c.mAlpha, 0.2f..1f, pct) { c.mAlpha = it }
    Spacer(Modifier.height(6.dp))
    SwitchRow("Полоска снизу (открывает меню)", c.bOn) { c.bOn = it }
    SliderRow("Прозрачность полоски", c.bAlpha, 0.2f..1f, pct) { c.bAlpha = it }
    Text(
        "Кнопку можно перетаскивать пальцем. FPS — частота кадров экрана, Ping — до 1.1.1.1.",
        fontSize = 11.sp, color = Color(0x77FFFFFF), modifier = Modifier.padding(top = 4.dp)
    )
}

@Composable
fun MenuTab(c: Cfg) = Column {
    Label("Цвет меню")
    ColorRow(c.accent) { c.accent = it }
    SliderRow("Размер меню", c.uiScale, 0.7f..1.4f, { "x%.2f".format(it) }) { c.uiScale = it }
    SliderRow("Прозрачность меню", c.uiAlpha, 0.5f..1f, pct) { c.uiAlpha = it }
    Label("Шрифт")
    Chips(fontNames, c.font) { c.font = it }
}

/* ─────────────── Мелкие компоненты ─────────────── */

@Composable
fun Label(t: String) =
    Text(t, fontSize = 12.sp, color = Color(0x99FFFFFF), modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))

@Composable
fun SwitchRow(title: String, v: Boolean, on: (Boolean) -> Unit) {
    val acc = LocalAccent.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { on(!v) }
            .padding(vertical = 4.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, Modifier.weight(1f), fontSize = 14.sp)
        Switch(
            v, on,
            colors = SwitchDefaults.colors(
                checkedTrackColor = acc, checkedThumbColor = Color.White,
                uncheckedTrackColor = Color(0x33FFFFFF), uncheckedThumbColor = Color(0xAAFFFFFF),
                uncheckedBorderColor = Color.Transparent, checkedBorderColor = Color.Transparent
            )
        )
    }
}

@Composable
fun SliderRow(
    title: String, v: Float, range: ClosedFloatingPointRange<Float>,
    fmt: (Float) -> String = { "%.2f".format(it) }, on: (Float) -> Unit
) {
    val acc = LocalAccent.current
    Column(Modifier.fillMaxWidth().padding(top = 4.dp)) {
        Row {
            Text(title, Modifier.weight(1f), fontSize = 13.sp)
            Text(fmt(v), fontSize = 13.sp, color = acc, fontWeight = FontWeight.Bold)
        }
        Slider(
            v, on, valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = acc, activeTrackColor = acc, inactiveTrackColor = Color(0x33FFFFFF)
            )
        )
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val acc = LocalAccent.current
    val bg by animateColorAsState(if (selected) acc else Color(0x22FFFFFF), tween(220), label = "chip")
    val fg = if (selected && acc.luminance() > .6f) Color.Black else Color.White
    Text(
        text, color = fg, fontSize = 13.sp,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(bg).clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Chips(items: List<String>, sel: Int, on: (Int) -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) { items.forEachIndexed { i, s -> Chip(s, i == sel) { on(i) } } }
}

@Composable
fun ColorRow(sel: Int, on: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        palette.forEach { c ->
            val s by animateDpAsState(if (c == sel) 34.dp else 26.dp, tween(180), label = "col")
            Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.size(s).clip(CircleShape).background(Color(c))
                        .border(
                            if (c == sel) 2.dp else 1.dp,
                            if (c == sel) Color.White else Color(0x44FFFFFF), CircleShape
                        )
                        .clickable { on(c) }
                )
            }
        }
    }
}

/* ─────────────── Подпись автора с иконками ─────────────── */

@Composable
fun Credits() {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxWidth().padding(top = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(Modifier.fillMaxWidth(0.5f).height(1.dp).background(Color(0x22FFFFFF)))
        Text("By", fontSize = 12.sp, color = Color(0x99FFFFFF))
        CreditRow(true, "Tt:@yrh_edits") { openUrl(ctx, "https://www.tiktok.com/@yrh_edits") }
        CreditRow(false, "Tg:@yrh_edits") { openUrl(ctx, "https://t.me/yrh_edits") }
        CreditRow(false, "Tgk:@standvisualsover") { openUrl(ctx, CHANNEL_LINK) }
    }
}

@Composable
private fun CreditRow(tt: Boolean, text: String, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (tt) TtIcon() else TgIcon()
        Text(text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun TgIcon(sz: Dp = 22.dp) = Canvas(Modifier.size(sz)) {
    val w = size.width
    drawCircle(Color(0xFF2AABEE))
    val p = Path().apply {
        moveTo(w * .22f, w * .49f); lineTo(w * .79f, w * .27f); lineTo(w * .67f, w * .76f)
        lineTo(w * .50f, w * .62f); lineTo(w * .39f, w * .72f); lineTo(w * .40f, w * .57f); close()
    }
    drawPath(p, Color.White)
}

@Composable
fun TtIcon(sz: Dp = 22.dp) = Canvas(Modifier.size(sz)) {
    val w = size.width
    drawRoundRect(Color(0xFF111111), cornerRadius = CornerRadius(w * .25f))
    fun note(c: Color, dx: Float) {
        val sw = w * .085f
        drawLine(c, Offset(w * .56f + dx, w * .20f), Offset(w * .56f + dx, w * .64f), sw)
        drawCircle(c, w * .14f, Offset(w * .46f + dx, w * .66f))
        drawLine(c, Offset(w * .56f + dx, w * .20f), Offset(w * .74f + dx, w * .36f), sw)
    }
    note(Color(0xFF25F4EE), -w * .03f)
    note(Color(0xFFFE2C55), w * .03f)
    note(Color.White, 0f)
}
