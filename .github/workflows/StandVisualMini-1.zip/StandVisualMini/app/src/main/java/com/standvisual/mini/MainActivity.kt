package com.standvisual.mini

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cfg = (application as App).cfg
        setContent { Root(cfg, tick) }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }
}

private val brandGrad = listOf(Color(0xFF7C5CFF), Color(0xFF00C2FF))

@Composable
fun Root(cfg: Cfg, tick: Int) {
    val ctx = LocalContext.current
    val canDraw = remember(tick) { Settings.canDrawOverlays(ctx) }
    CompositionLocalProvider(LocalContentColor provides Color.White) {
        Box(Modifier.fillMaxSize()) {
            AnimatedBackground()
            Crossfade(
                targetState = when { !cfg.unlocked -> 0; !canDraw -> 1; else -> 2 },
                animationSpec = tween(450), label = "step"
            ) { step ->
                when (step) {
                    0 -> GateScreen(cfg)
                    1 -> PermScreen()
                    else -> HomeScreen(cfg)
                }
            }
        }
    }
}

/* ───── Анимированный фон: градиент, мягкое свечение, плавающие точки ───── */

@Composable
fun AnimatedBackground() {
    val t = rememberInfiniteTransition(label = "bg")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val f by t.animateFloat(0f, 1f, infiniteRepeatable(tween(22000, easing = LinearEasing)), label = "f")
    val dots = remember {
        val r = java.util.Random(7)
        List(26) { floatArrayOf(r.nextFloat(), r.nextFloat(), 1.5f + r.nextFloat() * 2.5f, .3f + r.nextFloat() * .7f) }
    }
    Canvas(Modifier.fillMaxSize()) {
        drawRect(
            Brush.linearGradient(
                listOf(Color(0xFF0B0B18), Color(0xFF1A1040), Color(0xFF0B1A2E)),
                Offset.Zero, Offset(size.width * (.6f + a * .6f), size.height)
            )
        )
        val rad = size.minDimension * .9f
        val c = Offset(size.width * (.15f + .7f * a), size.height * .3f)
        drawCircle(Brush.radialGradient(listOf(Color(0x557C5CFF), Color.Transparent), c, rad), rad, c)
        for (d in dots) {
            val y = ((d[1] + f * d[3]) % 1f) * size.height
            val x = d[0] * size.width + sin(f * 6.28f * 3 + d[0] * 10f) * 12f
            drawCircle(Color.White.copy(alpha = .35f), d[2], Offset(x, y))
        }
    }
}

/* ───── Общие элементы ───── */

@Composable
fun Glass(content: @Composable () -> Unit) {
    val s = RoundedCornerShape(24.dp)
    Box(
        Modifier.fillMaxWidth().clip(s).background(Color(0x44141428)).border(1.dp, Color(0x33FFFFFF), s)
            .padding(22.dp)
    ) { content() }
}

@Composable
fun GButton(text: String, colors: List<Color> = brandGrad, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) .95f else 1f, tween(100), label = "press")
    Box(
        Modifier.fillMaxWidth().graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(RoundedCornerShape(16.dp)).background(Brush.horizontalGradient(colors))
            .clickable(interactionSource = src, indication = null, onClick = onClick)
            .padding(vertical = 15.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
}

/* ───── Экран 1: подписка ───── */

@Composable
fun GateScreen(cfg: Cfg) {
    val ctx = LocalContext.current
    var clicked by remember { mutableStateOf(false) }
    val pulse by rememberInfiniteTransition(label = "p")
        .animateFloat(1f, 1.07f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "pp")
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
        Arrangement.Center, Alignment.CenterHorizontally
    ) {
        Glass {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(
                    Modifier.size(84.dp).graphicsLayer { scaleX = pulse; scaleY = pulse }
                        .clip(CircleShape).background(Brush.linearGradient(brandGrad)),
                    contentAlignment = Alignment.Center
                ) { Text("✦", fontSize = 38.sp) }
                Text("Stand Visual Mini", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Для запуска визуалов нужно подписаться на канал",
                    textAlign = TextAlign.Center, color = Color(0xCCFFFFFF), fontSize = 15.sp
                )
                GButton("Подписаться  ✈") { clicked = true; openUrl(ctx, CHANNEL_LINK) }
                AnimatedVisibility(clicked, enter = fadeIn(tween(400)) + expandVertically(tween(400))) {
                    GButton("Я подписался — продолжить", listOf(Color(0xFF22C55E), Color(0xFF14B8A6))) {
                        cfg.unlocked = true
                    }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Credits()
    }
}

/* ───── Экран 2: разрешение «поверх других приложений» ───── */

@Composable
fun PermScreen() {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
        Arrangement.Center, Alignment.CenterHorizontally
    ) {
        Glass {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("🖥", fontSize = 44.sp)
                Text("Нужно разрешение", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Чтобы рисовать снег, цвета и меню поверх игры, включи «Поверх других приложений» для Stand Visual Mini.",
                    textAlign = TextAlign.Center, color = Color(0xCCFFFFFF), fontSize = 15.sp
                )
                GButton("Дать разрешение") {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                    )
                }
            }
        }
    }
}

/* ───── Экран 3: запуск и настройки ───── */

@Composable
fun HomeScreen(cfg: Cfg) {
    val ctx = LocalContext.current
    val run = OverlayService.running
    val dot by animateColorAsState(if (run) Color(0xFF22C55E) else Color(0xFF6B7280), tween(300), label = "dot")
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        OverlayService.start(ctx)
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Stand Visual Mini", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Glass {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(12.dp).clip(CircleShape).background(dot))
                    Text(if (run) "Оверлей работает" else "Оверлей выключен", fontSize = 16.sp, fontWeight = FontWeight.Medium)
                }
                GButton(
                    if (run) "Остановить" else "Запустить визуалы",
                    if (run) listOf(Color(0xFFEF4444), Color(0xFFF97316)) else brandGrad
                ) {
                    if (run) OverlayService.stop(ctx)
                    else if (Build.VERSION.SDK_INT >= 33 &&
                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED
                    ) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    else OverlayService.start(ctx)
                }
                Text(
                    "После запуска открой игру: слева вверху будет кнопка Stand visual mini, снизу — полоска. Тап по ним открывает и закрывает меню.",
                    fontSize = 12.sp, color = Color(0x99FFFFFF)
                )
            }
        }
        MenuPanel(cfg, null, false)
    }
}
